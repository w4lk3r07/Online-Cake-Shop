<?php
session_start();
if(!isset($_SESSION["user"]))  
 {       
  header("location:index.php");
}

include 'connect.php';
$USERNAME=$_SESSION['user'];
$query="SELECT id From users where USERNAME='$USERNAME'";
$id1=mysqli_query($conn,$query);
while($iid=mysqli_fetch_array($id1))
    {
$sql="SELECT product_id from payment INNER JOIN users on users.id=payment.customer_id where customer_id='$iid[0]'";
$result=mysqli_query($conn,$sql);
//print_r($result)

?>

<!DOCTYPE html>
<html>
<head>
  <title>My Orders</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
   </style>
</head>

<body>
  <style type="text/css">
    h3{
      font-size: 20px;
    }
footer {
   position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: red;
   color: white;
   text-align: center;
}
body{
     background-image: url(./images/background.jpg);
     }
.bg-info{
      background-color: dimgray !important;
     }
  </style>
<nav class="navbar navbar-expand-md bg-dark navbar-dark">
  <!-- Brand -->
   <img src="./images/logo.png" style="width: 5%">
  <a class="navbar-brand" href="index.php">Cake Shop</a>

  <!-- Toggler/collapsibe Button -->
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>

  <!-- Navbar links -->
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item">
        <a class="nav-link" href="index.php">Home</a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         Category
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown" style="background-color: rgb(52,58,64);">
          <a class="dropdown-item " href="chocolate.php" style="color: rgb(153,156,159);">Chocolate</a>
          <a class="dropdown-item " href="redVelvet.php" style="color: rgb(153,156,159);">Red Velvet</a>
          <a class="dropdown-item " href="strawberry.php" style="color: rgb(153,156,159);">Strawberry</a>
          <a class="dropdown-item " href="blackForest.php" style="color: rgb(153,156,159);">Black Forest</a>
      </li>
      <?php
      if(!isset($_SESSION["user"]))  
 {       
 ?>
      <li class="nav-item">
        <a class="nav-link" href="login.php">LOGIN</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="insert.php">SIGN UP</a>
      </li>
<?php
}  
if(isset($_SESSION["user"]))  
 {       
 ?>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         Hi <?php echo $_SESSION["user"]?>
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown" style="background-color: rgb(52,58,64);">
          <a class="dropdown-item " href="myorder.php" style="color: rgb(153,156,159);">My Orders</a>
          <a class="dropdown-item " href="logout.php" style="color: rgb(153,156,159);">Logout</a>
      </li>
<?php
}  
?>
    </ul>
  </div>
</nav> 

<div class="container">
    <div class="card deck">
        <div class="card border-info p-2 text-center">
          <div class="row">
            <div class="col-lg-3">
          <h3>Image</h3>
        </div>
        <div class="col-lg-3">
          <h3> Product Description</h3>
        </div>
        <div class="col-lg-3">
          <h3>Price</h3>
        </div>
        <div class="col-lg-3">
          <h3>Status</h3>
        </div>
      </div>
        </div>
      </div>
    </div>
      <?php
//print_r($result);
if (mysqli_num_rows($result)>0) {
while($row=mysqli_fetch_array($result))
    {
        # code...
      
      $sql1="SELECT * from product where id='$row[0]'";
$result1=mysqli_query($conn,$sql1);
while($row1=mysqli_fetch_array($result1))
    {
      ?>
<div class="container mb-2">
<div class="card deck">
        <div class="card border-info p-2 bg-info text-center">
          <div class="row">
            <div class="col-lg-3">
          <img src="<?php echo $row1['product_Image'];?>" class="card-img-top" height="160">
        </div>
        <div class="col-lg-3">
          <h5 class="card-title"><?php echo $row1['product_name']; ?></h5>
        </div>
        <div class="col-lg-3">
          <h3><?php echo number_format($row1['product_price']);?></h3>
        </div>
        <div class="col-lg-3">
          <h3>Purchased</h3>
        </div>
      </div>
        </div>
      </div>
  </div>
  <?php
}
}
}
else
{?>
  <div class="container mt-5">
    <div class="card deck">
        <div class="card border-info py-5 text-center ">
          <div class="row">
            <div class="col-lg-12">
          <h3>Sorry, You haven't purchased anything yet...</h3>
        </div>
        </div>
    </div>
   <?php
}
}
?>
</body>
<footer class="ftco-footer ftco-section bg-dark text-center">
    <div class="container">
      <h5  class="mb-0" style="color: white;" >All Rights are reserved by Cake Shop</h5>
      </div>
    </footer>
</html>
<?php
//creating connection to connect the database.
$hostname="localhost";
$username="root";
$password="";
$database="cakeshop";
	// $conn=mysqli_connect('localhost','root','','shopping');
$conn=mysqli_connect($hostname,$username,$password,$database);
	if (!$conn) {
		# code...
		die("could not connect to the database".mysqli_connect_error());
	}
?>
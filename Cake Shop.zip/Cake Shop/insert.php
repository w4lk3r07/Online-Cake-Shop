<!DOCTYPE html>
<html lang="">

<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up</title>
    <link rel="stylesheet" href="style.css">
    <style type="text/css">
        body{
            background-color: darkslategray;
        }
    </style>
</head>

<body>
    <div class="container">
      
       <!-- INSERT DATA -->
        <div class="form">
            <h2 style="color: white;">Sign Up</h2>
            <form id="myForm">
                <strong style="color: white;">NAME</strong><br>
                <input type="text" name="NAME" placeholder="Enter your full name" pattern="[A-Za-z -]+$" required><br><br>
                <strong style="color: white;">Email</strong><br>
                <input type="email" name="EMAIL" placeholder="Enter your email" title="e.g., abc123@gmail.com" required><br><br>
                <strong style="color: white;">Contact No</strong><br>
                <input type="tel" name="CONTACTNO" placeholder="10 Digit contact no:" pattern="[0-9]{10}" title="Must input 10 digits" required><br><br>
                <strong style="color: white;">USERNAME</strong><br>
                <input type="text" name="USERNAME" placeholder="Enter your user name" required><br><br>
                <strong style="color: white;">PASSWORD</strong><br>
                <input type="password" name="PASSWORD" placeholder="Enter your password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters"  required><br><br>
                <input type="submit" value="Sign Up">
            </form>
        </div>
        <!-- END OF INSERT DATA SECTION -->
        <form action="login.php"><br>
            <strong style="color: white;">Already have an account? Click here to login </strong><br><br>
            <input type="submit" value="Login">
        </form>




<script>
    $('#myForm').on('submit', function(e) {
        e.preventDefault()
        $.ajax({
            url: 'store.php',
            type: 'POST',
            contentType:false,
            cache:false,
            processData:false,
            data:  new FormData(this),
            success: function(obj) {
                console.log("Response: " + obj)
                
                obj = JSON.parse(obj);
                if(obj.status=="already exist")
                {
              swal("Sign up Failed", "Email or Username already exists", "warning").then(function(obj) {
   location.href = "insert.php";
});
                }
                else if(obj.status=="success")
                {
              swal("Successful", "Successfully Signed Up", "success").then(function(obj) {
   location.href = "index.php";
});
                }
                else if(obj.status=="failure")
                {
              swal("failure", "please insert correct data", "warning").then(function(obj) {
   location.href = "insert.php";
});
                }
                else if(obj.status=="invalid email")
                {
              swal("failure", "please insert valid email", "warning").then(function(obj) {
   location.href = "insert.php";
});
                }
                else if(obj.status=="fields required")
                {
              swal("failure", "please insert correct data", "warning").then(function(obj) {
   location.href = "insert.php";
});
                }
            },
            error: function(obj){
                console.log(obj)
                alert('error')
            }
        });
    });
</script>




    </body>
</html>
   

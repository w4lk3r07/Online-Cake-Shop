-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 23, 2024 at 10:42 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cakeshop`
--

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(10) UNSIGNED NOT NULL,
  `usname` varchar(30) DEFAULT NULL,
  `pass` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `usname`, `pass`) VALUES
(1, 'Admin', '123');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `pay_id` int(11) NOT NULL,
  `payment_id` varchar(255) DEFAULT NULL,
  `order_id` varchar(255) DEFAULT NULL,
  `signature_hash` varchar(255) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `customer_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`pay_id`, `payment_id`, `order_id`, `signature_hash`, `product_id`, `customer_id`) VALUES
(1, 'pay_FklJVugv7kMk5D', 'order_FklGBP3cAdqPiH', 'bd9c8958a4334fd9ad031c6073219e5c3ff0ca5a59b71eacb8cf6d3adc928998', NULL, 0),
(2, 'pay_FklpUenRVeSvPk', 'order_FkloZEVpcZyM6c', '9de44975dab8c911da91c6f6c194891152b2491bbf88bb229ba6eb0989ac4a90', 4, 0),
(3, 'pay_FkmsCrp7jw2z8K', 'order_FkmraT8r061FFE', 'c80d18c5084ae78efdeaa8ef285b71ea7acd322a51a5e38b8bf0b39ee1283794', 7, 0),
(4, 'pay_FkmsCrp7jw2z8K', 'order_FkmraT8r061FFE', 'c80d18c5084ae78efdeaa8ef285b71ea7acd322a51a5e38b8bf0b39ee1283794', 7, 0),
(5, 'pay_FkmsCrp7jw2z8K', 'order_FkmraT8r061FFE', 'c80d18c5084ae78efdeaa8ef285b71ea7acd322a51a5e38b8bf0b39ee1283794', 7, 0),
(6, 'pay_FknOSSkusVnKQC', 'order_FknK8erafI8cKJ', '2c6d05e20611b22e4e666424a0512f514a5e4dbb06421dbfbf5ba86b6a66c57c', 4, 0),
(7, 'pay_FkngOH8TSlPRB3', 'order_Fkne4LkNFt1JpI', '59166d6d1b3a92f08be840e84d0f13ef60ef1575fbf955db374e636068019807', 4, 0),
(8, 'pay_FknjhZ9k1ZUPOq', 'order_FkniWqJG2n8o3e', '41154077f33b1a49c11c1ba5facbf9b30aafab84bb82ebf749ef513ad95d34e9', 8, 0),
(9, 'pay_Fko0sbvyRlrHM3', 'order_FknzK7JLakaS0n', '6970f19d5603f00d7e6bcdc6ba7509750376586598fbb80c820e84bdfcb282f9', 10, 0),
(10, 'pay_FkoRRAVy3gDIl4', 'order_FkoQGpdDbpQarV', '9247d03bf4d85c60919452920a26b0496ef6625468eab00e292df70a6918447e', 6, 0),
(11, 'pay_G4goFz4EPKcScN', 'order_G4gne23RRsL8m7', 'e6cd3a12a927d808b483b3a9dcd6497fc2c6c893f8418f36ef1d2085b7a2408a', 4, 0),
(12, 'pay_G4gug2fb7iO1oD', 'order_G4guJVUderelUQ', 'ff842ad7b72dbaee314b0be788e430243dc0b55508a80ee723478db2c5bdfda7', 4, 0),
(13, 'pay_G5QPrMOYryDjl0', 'order_G5QPNAbr4lN405', '02c297bc979c0f5e2ad9af49af9fe4068d254ec745265aa7386e25ce53caf155', 4, 0),
(14, 'pay_G5URfMDUjqIVrD', 'order_G5URJP2ovqXwWS', '5d69a6eacfba17b67bdc1b468b0ad559f99f4cbf11f446454e739d611cf4ecb2', 4, 0),
(15, 'pay_G6UgL9ebiDRw0N', 'order_G6UfpHyA8ECxIo', 'c86beca1dff38dfba81dd5dcf87db50edd5b8c824a93d7b5ab6ee830df1ac672', 4, 0),
(16, 'pay_G6sEzUTz33k3Q6', 'order_G6sEjlmNaeBhX9', 'e1f06d0e62c8479b1dc11c8d1e197f4108245b38cf42755810e2cd3441c2589b', 4, 0),
(17, 'pay_G6sWcFwpJftMAd', 'order_G6sW6Exe7XKu0V', 'bc1030e42dcc9b36270b3bd93fac931dd3545bedb0ccec25614d32e26f67a5aa', 4, 0),
(18, 'pay_G6sfJR2qiYrZWs', 'order_G6sf6sWWk5Y7ni', 'f70ad6e26323f62483c6bed8e21863207d8d6693aa5eb0b3ed7846c98d842ae7', 6, 0),
(19, 'pay_G6sj4xyLczV1O9', 'order_G6shKPmPKaRD3p', '391a5981d1dc87a929b60c2fa84bd5bbd6afeba1278b3657643f44e6c9bd2d84', 6, 0),
(20, 'pay_G6sjaGUGCyvwUd', 'order_G6sjOYpSMHfEid', 'b62f4c6330d5bcbc6a4b50890f15ed7253603d16f0103bfc5618e81bc3e1a6c6', 6, 38),
(21, 'pay_G6tzYmFnP14UQ6', 'order_G6tyuArAsRSFXM', 'dd6ebcfcc8a217419135896e88a465dd70d6fb7a89db57b940dc8995fcb1ec6c', 5, 6),
(22, 'pay_G6yZT6FfNgVT3p', 'order_G6yZ3AJ6XnqhyK', '941994a6c4f416667d7f3afe8e0a70d1c7bfd6fb181bf98bf036e39c1edf0b6f', 4, 6),
(23, 'pay_G6zLUY761PKbTR', 'order_G6zJw0mC80Q9Hn', '4fa58510155a67011a36f9197d13ffd37592a91c9ced5fb4999b5d9534603fe7', 5, 6),
(24, 'pay_G7G1NpRg7od352', 'order_G7G0vHxDLmMTby', '3b4eaf2011ab336dd95def484315751b9658d4dd72d5dfda9a221dbcc0fd7821', 29, 39),
(25, 'pay_G7G5yr1OnC0D4T', 'order_G7G5TMpRgzzNZ1', '68d2322005beaaec92a27229e2bf5d5b5905b55620d7aec498b393c3d03b10f7', 29, 6),
(26, 'pay_G7GN4mzX2mHdP0', 'order_G7GLvlZXCDzj8r', '1c71cdb629ef47b488f61071a6939e22bd734692da3ec3a07dd8cf768e30c2cf', 5, 39),
(29, 'pay_G7JLHDUDslwC4b', 'order_G7JKr2Wrbg6TSx', '85c64b4dc9400310f29503d2ab8d9e69b40810e767173b5dbf1a2170760a2137', 5, 6),
(30, 'pay_G7NK6NumHmpULD', 'order_G7NJ4K7arOWlOm', 'ec894f208c12bfe2f46e5318829403d84a9da03b5a46e065df9d387e7294ba8e', 5, 40),
(31, 'pay_H1zgxLa79Giv1c', 'order_H1zg6fjsa75922', '86284ff4101af7d6447a3ab70e683f8437486a4388cb14ea49cda156e418ec0b', 40, 41),
(32, 'pay_H20c0KPnNzIQEQ', 'order_H20bkd8tie5u6Q', '74792476c1982f55194ba84b6787fa737ac327284efc205ae9ead29d0b31ed1c', 39, 42),
(33, 'pay_H20n85aNOUUZwH', 'order_H20mz8LdrCGm30', '862f57813c8d5974cf3c39460e91082030eeee6ac0565938d60938258867236a', 57, 43),
(34, 'pay_H36W4heK7LwUvU', 'order_H36VOw9Hq2lKBh', '8f9b9b4f4b4cb4e9805868a38b880367fb36c01e936c5ac4c4348a145b90c0c4', 62, 41),
(35, 'pay_Ll5UmkNbmFnQWE', 'order_Ll5UY7UMGw0gX8', '0282415d00fce37ca3476d0b7271561bdd34443a1b34e088e39b7f506d886a10', 39, 44),
(36, 'pay_Ll5ambEr7G5mJS', 'order_Ll5aYsP5YcKRhj', 'a465c721966ce7c2b014d56d53c1cacf2d82b7d62047a40e6c564bd6faed5e2b', 40, 44),
(37, 'pay_Ll6xrXUTtmsmBj', 'order_Ll6xewjuOOB0Zm', '97d8d54e272a4c9c04bbb42c7542cd85d7a850d3b3ae7c526382af06ac78373c', 54, 45),
(38, 'pay_Ll7GoouZZSEEEJ', 'order_Ll7GWaV0MzMqpf', '213b631c1a9ccd8eff4be9926389a286b87eecb3bccb4656cdf652878fd63a77', 40, 45),
(39, 'pay_Ll9QCTAj1Rc5D5', 'order_Ll9Pak882VxmBF', '7d884420c3021b2637d2317c6fac6e8245a9508772bc2bbd653c44e5373da1a0', 40, 44);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_price` bigint(20) NOT NULL,
  `category` varchar(255) NOT NULL DEFAULT 'electronics',
  `product_Image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `product_name`, `product_price`, `category`, `product_Image`) VALUES
(39, 'Sinful chocolate truffle:- especially when it looks like this bombshell of a chocolate delight! This Chocolate Perfect for birthday, anniversary and all happy celebrations.', 500, 'chocolate', 'images/choco sinful.jpeg'),
(40, 'Chocolate Rose Designer Cake:- Especially designed with roses for your loved ones', 700, 'chocolate', 'images/choco rose.jpeg'),
(41, 'Assorted choco chips cake:-oothe your senses by gorging on this sinfully delicious choco chips cake enriched with exotic chocolates that you have never tasted before. Coated with crunchy choco chips, this mouthwatering cake is topped with chocolate syrups', 699, 'chocolate', 'images/choco assor.jpeg'),
(42, 'Choco walnut delight:- With finely chopped walnut chunks, maraschino cherries and chocolate crowned on top, this cake is all yours to have.', 849, 'chocolate', 'images/choco walnut.jpeg'),
(47, 'Artistic chocolate pleasure:- The mushy chocolatey base finished perfectly with chocolate cream and artistic design is sure to please everyone in the crowd.', 800, 'chocolate', 'images/chco ary.jpeg'),
(49, 'Heart shaped red velvet cake:-The red velvet topping the mushy layers spell Love so well that would warm the heart even on the coldest of days!', 849, 'red velvet', 'images/rose heart.jpeg'),
(50, 'Red velvet crunchy delight:- Here is a mouth watering red velvet cake enriched with nutritious walnuts which makes this cake a perfect delicacy to gorge on every special occasions.', 1099, 'red velvet', 'images/red crunchy.jpeg'),
(51, 'Red Velvety and Fruity Delight:-Enriched with red velvet shavings, this cake is topped with luscious fruits which makes it a perfect treat to celebrate your special occasions with.', 999, 'red velvet', 'images/red fruit.jpeg'),
(52, 'Cherrylicious Red Velvet Cake:-Garnished with dark chocolates, this captivating cake is topped with a luscious cherry on the top.', 899, 'red velvet', 'images/red cherry.jpeg'),
(53, 'Red Velvet Little Heart Cake:We have taken the Red Velvet to the whole new level of deliciousness. Adorned with Red Velvet crumbs, this delight makes a perfect expression of love.', 999, 'red velvet', 'images/red little.jpeg'),
(54, 'Velvety Affair Cake:- Red and white, both opposite tones of color when it comes together make red velvet cake. This cake is as smooth as velvet can be and upon that the cake is very delectable.', 899, 'red velvet', 'images/red affairr.jpeg'),
(55, 'Tempting Truffle Cake:-With its mushy base and luscious chocolate glaze, this Chocolate Truffle is a drool worthy treat for all the times you wish to gorge on something delicious.', 699, 'chocolate', 'images/choco tuffl.jpeg'),
(56, 'Chocolicious Black Forest Gateau:- Relish this devilishly delicious Black forest cake enriched with fresh vanilla cream and garnished with chocolate shavings on the top and by the side.', 1089, 'Black Forest', 'images/black gareu.jpeg'),
(57, 'Heart Shape Black Forest Cake -Here is a mouthwatering Heart-Shaped Black Forest Cake to express your love for your special one in a special way.', 899, 'Black Forest', 'images/black heart.jpeg'),
(58, 'Delectable Black Forest Treat:- This cake is completely covered with lip smacking white cream and rounded with chocolate shavings. The beautiful garnish of chocolate shaving and cherries makes this cake a perfect treat from heaven.', 949, 'Black Forest', 'images/black delec.jpeg'),
(59, 'Savory Treat Of Black Forest:- This German classic comes layered with chocolate and whipped cream. This cake is nicely topped up with maraschino cherries and chocolate glaze.', 749, 'Black Forest', 'images/black savory.jpeg'),
(60, 'Palpable Black Forest Cake:- V', 899, 'Black Forest', 'images/black pala.jpeg'),
(61, 'Palpable Black Forest Cake:- get your friend and family a cake which is chocolaty, creamy and can never be put aside by anyone to it later. Unfold some chocolaty moments with your people with the help of this cake.', 599, 'Black Forest', 'images/black gareu.jpeg'),
(62, 'Iconic Strawberry Cake:- Heavenly tasting strawberry syrup mixed with fresh cream is what makes each bite more delicious than the last in this strawberry cake.', 849, 'Strawberry', 'images/straw iconic.jpeg'),
(63, 'Strawberry fruit cake:- Cake covered in strawberry syrup and fruits is a best treat for your loved ones.', 659, 'Strawberry', 'images/sraw fruit.jpeg'),
(65, 'Rosy Delight :-Glazed with melting strawberry on a rich, moist vanilla cake, Rosy delight is utterly delicious and works wonders when it comes to bonding with your loved one.', 849, 'Strawberry', 'images/rose delight.jpeg'),
(66, 'Sweet Symphony:- Its heavenly flavor and soulful creamy strawberry frosting along with crowned chocolate create an everlasting symphony while the fluffy sponge cake adds more to the oozing ecstasy.', 999, 'Strawberry', 'images/sweet  sym.jpeg'),
(67, 'Strawberry Delicacy:-this cake is adorned with swirls of fresh creamy strawberry and a cherry on the top. Order this strawberry cake on special occasions and infuse sweetness in your celebrations.', 899, 'Strawberry', 'images/sraw delicay.jpeg'),
(68, 'Heart Shape Strawberry Rose Cake:- The perfect strawberry fondant roses on top of this cake have made it look really exquisite. Buy this super sumptuous cake and make your special one feel really loved like never before.', 1099, 'Strawberry', 'images/strwa rose.jpeg'),
(69, 'Chocolate truffle cake:Laden with Rich Creamy Molten Chocolate on the inside, and Chocolate bars on the top, this freshly baked Chocolate Cake suitable for celebrating special Birthdays, Anniversaries etc and making them more memorable.', 699, 'chocolate', 'images/truf.jpeg'),
(70, 'Glazing Chocolate Beauty :- fully loaded with chocolate', 999, 'chocolate', 'images/glaz.jpeg'),
(71, 'Cherry on the black forest: Baked with the richness of chocolate and fresh vanilla cream, this arresting Black forest cake is topped with the luscious cherries that will let you surrender all your senses to it.', 1099, 'Black Forest', 'images/blck cherry.jpeg'),
(72, 'Decadent black forest cake: Delicious is the only world that can define this cake in a best way. Each piece of this decadent heart shaped Black Forest cake can fill your mouth with ultimate dessert satisfaction.', 849, 'Black Forest', 'images/blck decad.jpeg'),
(73, 'Radiant bliss:-Lovingly garnished with sumptuous ingredients from the cherry family, this red velvet cake completely stands out from the crowd in terms of taste and elegance.', 849, 'red velvet', 'images/red bliss.jpeg'),
(74, 'Chocoholic red velvet cake:- Each bite of this cake will fill your mouth with the ultimate dessert satisfaction. Share this heavenly joy with your loved one and turn any moment into a magical one.', 1500, 'red velvet', 'images/red choco.jpeg'),
(75, 'Berry rush:- Overloaded with ripe cherries on one side and chocolate on the other, this delight is jam-packed with strawberry whipped cream. A delight for both heart and health, this delight is sure to swoon your loved ones with the sweetest symphony ever', 999, 'Strawberry', 'images/straw kk.jpeg'),
(76, 'Strawberry symphony:-', 849, 'Strawberry', 'images/steee.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `NAME` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `EMAIL` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `USERNAME` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `PASSWORD` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `CONTACTNO` bigint(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `NAME`, `EMAIL`, `USERNAME`, `PASSWORD`, `CONTACTNO`) VALUES
(41, 'Viraj', 'vit@gmail.com', 'viru', 'ee', 1111111111),
(42, 'viraj', 'viru@gmail.com', 'viraj', 'ee', 8889898989),
(44, 'vadddya', 'aa@gmail.com', 'okok', '123', 9888888888),
(45, 'Kedar Dode', 'kedardode1131@gmail.com', 'kedar123', 'Kedar123', 9075306630);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`pay_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `EMAIL` (`EMAIL`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `pay_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=79;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

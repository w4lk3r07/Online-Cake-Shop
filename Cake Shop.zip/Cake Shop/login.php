<?php
//require 'setcookies.php';
?>
<?php
//if($_response['status']=="true")
{
   // header("Location:show.php");
    //exit;
}
?>
<!DOCTYPE html>
<html lang="">

<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="style.css">
    <style type="text/css">
        body{
            background-color: darkslategray;
        }
    </style>
</head>

<body>
    
    <div class="container">
      
       <!-- INSERT DATA -->
        <div class="form">
            <h2 style="color: white;">LOGIN</h2>
            <form id=myForm1>
                <strong style="color: white;">USERNAME</strong><br>
                <input type="text" name="USERNAME" placeholder="Enter your user name" required><br><br>
                <strong style="color: white;">PASSWORD</strong><br>
                <input type="password" name="PASSWORD" placeholder="Enter your password" required><br><br>
                <input type="submit" value="Login">
            </form>
            </div>
            
            <br><strong style="color: white;">Don't have an account? Click here to sign up </strong><br><br>
            <a href="insert.php"><input type="submit" value="Sign Up">
        </form>
        
        <!-- END OF INSERT DATA SECTION -->
        <script>
    $('#myForm1').on('submit', function(e) {
        e.preventDefault()
        $.ajax({
            url: 'store1.php',
            type: 'POST',
            contentType:false,
            cache:false,
            processData:false,
            data:  new FormData(this),
            success: function(obj) {
                console.log("Response: " + obj)
                
                obj = JSON.parse(obj);
                if(obj.status=="insert valid username or password ")
                {
              swal("failure", "please insert valid username or password", "warning").then(function(obj) {
   location.href = "login.php";
});
                }
                else if(obj.status=="success")
                {
              swal("Success", "Successfully LOGIN", "success").then(function(obj) {
   location.href = "index.php";
});
                }
                else if(obj.status=="failure")
                {
              swal("failure", "please insert correct data", "warning").then(function(obj) {
   location.href = "login.php";
});
                }    
            },
            error: function(obj){
                console.log(obj)
                alert('error')
            }
        });
    });
</script>

    </body>

</html>

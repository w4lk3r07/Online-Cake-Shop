<?php
session_start()

?>

<!DOCTYPE html>
<html>
<head>
	<title>Chocolate Cake</title>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>
  <style type="text/css">
footer {
   
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: red;
   color: white;
   text-align: center;
}
  body{
     background-image: url(./images/background.jpg);
     }
  </style>
<nav class="navbar navbar-expand-md bg-dark navbar-dark">
  <!-- Brand -->
   <img src="./images/logo.png" style="width: 5%">
  <a class="navbar-brand" href="index.php">Cake Shop</a>

  <!-- Toggler/collapsibe Button -->
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>

  <!-- Navbar links -->
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item">
        <a class="nav-link" href="index.php">Home</a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         Category
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown" style="background-color: rgb(52,58,64);">
          <a class="dropdown-item " href="chocolate.php" style="color: rgb(153,156,159);">Chocolate</a>
          <a class="dropdown-item " href="redVelvet.php" style="color: rgb(153,156,159);">Red Velvet</a>
          <a class="dropdown-item " href="strawberry.php" style="color: rgb(153,156,159);">Strawberry</a>
          <a class="dropdown-item " href="blackForest.php" style="color: rgb(153,156,159);">Black Forest</a>
      </li>
      <?php
      if(!isset($_SESSION["user"]))  
 {       
 ?>
      <li class="nav-item">
        <a class="nav-link" href="login.php">LOGIN</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="insert.php">SIGN UP</a>
      </li>
<?php
}  
if(isset($_SESSION["user"]))  
 {       
 ?>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         Hi <?php echo $_SESSION["user"]?>
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown" style="background-color: rgb(52,58,64);">
          <a class="dropdown-item " href="myorder.php" style="color: rgb(153,156,159);">My Orders</a>
          <a class="dropdown-item " href="logout.php" style="color: rgb(153,156,159);">Logout</a>
      </li>
<?php
}  
?>
    </ul>
  </div>
</nav> 
<?php
include 'connect.php';
//selecting all products from production and showing result in frontend 
$sql="SELECT * FROM product where category='chocolate'";
$result=mysqli_query($conn,$sql);
?>
<div class="container">
	<div class="row">
		<?php
		while($row=mysqli_fetch_array($result))
		{
		?>
		<div class="col-lg-3 mt-3 mb-3">
			<div class="card deck">
				<div class="card border-info p-2 ">
					<img src="<?php echo $row['product_Image'];?>" class="card-img-top" height="170">
					<h5 class="card-title" style="height: 40px;">Product :<?php echo substr($row['product_name'], 0, 20); ?>...</h5>
					<h3>Price :<?php echo number_format($row['product_price']);?></h3>
					<a href="order.php?id=<?php echo $row['id'];?>" class="btn btn-danger btn-block btn-lg ">Buy Now</a>
				</div>
			</div>
		</div>
		<?php
	}
	?>
	</div>
	
</div>
</body>
<footer class="ftco-footer ftco-section bg-dark text-center">
    <div class="container">
      <h5  class="mb-0" style="color: white;" >All Rights are reserved by Cake Shop</h5>
      </div>
    </footer>
</html>

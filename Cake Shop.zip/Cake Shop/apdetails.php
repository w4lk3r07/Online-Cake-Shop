<?php
session_start();
if(isset($_SESSION['user']))
{
include 'connect.php';

$id=$_GET['id'];
$total=$_GET['total'];
// echo $total;
//Print_r($ids);
//feching details of perticular item by its id
?>
<!DOCTYPE html>
<html>
<head>
	<title>Customer Details</title>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <style type="text/css">
    body{
     background-image: url(./images/background.jpg);
     }
    footer {
     position: fixed;
     left: 0;
     bottom: 0;
     width: 100%;
     background-color: red;
     color: white;
     text-align: center;
}
  </style>
</head>
<body>
	<nav class="navbar navbar-expand-md bg-dark navbar-dark">
  <!-- Brand -->
  <a class="navbar-brand" href="index.php">Cake Shop</a>

  <!-- Toggler/collapsibe Button -->
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>

  <!-- Navbar links -->
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item">
        <a class="nav-link" href="index.php" >Home</a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         Category
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown" style="background-color: rgb(52,58,64);">
          <a class="dropdown-item " href="chocolate.php" style="color: rgb(153,156,159);">Chocolate</a>
          <a class="dropdown-item " href="redVelvet.php" style="color: rgb(153,156,159);">Red Velvet</a>
          <a class="dropdown-item " href="strawberry.php" style="color: rgb(153,156,159);">Strawberry</a>
          <a class="dropdown-item " href="blackForest.php" style="color: rgb(153,156,159);">Black Forest</a>

      </li>
      <?php
      if(!isset($_SESSION["user"]))  
 {       
 ?>
      <li class="nav-item">
        <a class="nav-link" href="login.php">LOGIN</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="insert.php">SIGN UP</a>
      </li>
<?php
}  
if(isset($_SESSION["user"]))  
 {       
 ?>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         Hi <?php echo $_SESSION["user"]?>
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown" style="background-color: rgb(52,58,64);">
          <a class="dropdown-item " href="myorder.php" style="color: rgb(153,156,159);">My Orders</a>
          <a class="dropdown-item " href="logout.php" style="color: rgb(153,156,159);">Logout</a>
      </li>
<?php
}  
?>
    </ul>
  </div>
</nav> 
	<style >
 #strong{ 
			text-align: left;
		}
		.container {
     max-width: 400px;
     margin: 0 auto;
     border: 3px solid #333;
     padding: 10px;
     margin-top: 20px;
     text-align: center;

 }
.form input[type="text"],
 input[type="email"],
 input[type="password"],
 input[type="tel"] {
   width: 80%;
   padding: 10px;
   font-size: 16px;
   margin: 3px 0;
   border: 1px solid #ccc;
 }
.form input[name="QUARY"] {
   width: 80%;
   height:100px;
   padding: 10px;
   font-size: 16px;
   margin: 3px 0;
   border: 1px solid #ccc;
 }

.form input[type="submit"] {
   margin-top: 5px;
   padding: 6px 26px;
   font-size: 20px;
   cursor: pointer;
   background-color: rgba(30, 20, 96,1);
   color: #FFF;
   outline: none;
   border: 1px solid rgba(0, 0, 0, .1);
   height: 50px;
 }
footer {
   position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: red;
   color: white;
   text-align: center;
}
	</style>
  <?php
if(isset($_SESSION))
{
  $USERNAME=$_SESSION['user'];
  $usql="SELECT * FROM users WHERE USERNAME='$USERNAME'";
  $result1=mysqli_query($conn,$usql);
  while($row1=mysqli_fetch_array($result1))
  {
  // 


   ?> 
<div class="container">
  <div class="form">
            <h2 style="color: white;">Personal Information</h2>
            <hr style="height:2px;width:50px;color:blue;background-color:rgba(30, 20, 96,1);margin-left: 45%">
            <form id="myForm" action="pay.php" method="POST">
                <strong style="align-items: left; color: white;">Customer Name:</strong><br>
                <input type="text" name="NAME" value="<?php echo $row1['NAME'];?>" readonly><br>
                <strong style="color: white;">Customer Email:</strong><br>
                <input type="email" name="EMAIL" value="<?php echo $row1['EMAIL'];?>" readonly><br>
                <strong style="color: white;">Customer Contact No:</strong><br>
                <input type="tel" name="CONTACTNO"value="<?php echo $row1['CONTACTNO'];?>" pattern="[0-9]{3}[0-9]{3}[0-9]{4}" readonly><br>
                <strong style="color: white;">Total Price:</strong><br>
                <input type="text" name="Price" value="<?php echo $total;?>" readonly><br>
                <input type="text" name="product_id" value="<?php echo $id;?>" hidden>
                <input type="text" name="customer_id" value="<?php echo $row1['id'];?>" hidden>

                <input type="submit" value="Proceed">
            </form>
        </div>
    </div>
    <?php
}
}
}

else{
  header("location:login.php");
}
?>
</body>
<footer class="ftco-footer ftco-section bg-dark text-center">
    <div class="">
      <h5  class="mb-0" style="color: white;" >All Rights are reserved by shopping</h5>
      </div>
</footer>
</html>
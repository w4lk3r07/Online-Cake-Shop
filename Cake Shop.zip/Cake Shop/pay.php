<html>
<head>
<title>Payment</title>
</head>
</html>
<?php
include 'connect.php';
include 'razorpay/Razorpay.php';

use Razorpay\Api\Api;
//  curl -u rzp_test_UuqopNwEkHsRf5:jjpRUMAWVRjuOeNABjbKUPSN \-X POST https://api.razorpay.com/v1/payment_links/ \-H 'Content-type: application/json' \-d '{  "amount": 1000,  "currency": "INR",  "accept_partial": true,  "first_min_partial_amount": 100,  "expire_by": 1691097057,  "reference_id": "TS1989",  "description": "Payment for policy no #23456",  "customer": {    "name": "Gaurav Kumar",    "contact": "+919999999999",    "email": "gaurav.kumar@example.com"  },  "notify": {    "sms": true,    "email": true  },  "reminder_enable": true,  "notes": {    "policy_name": "Jeevan Bima"  },  "callback_url": "https://example-callback-url.com/",  "callback_method": "get"}'
//  curl -u rzp_test_UuqopNwEkHsRf5:jjpRUMAWVRjuOeNABjbKUPSN \
// -X POST https://api.razorpay.com/v1/invoices/ \
// -H 'Content-type: application/json' \
// -d '{
//   "customer": {
//     "name": "vinayakgodse",
//     "email": "vinayakgodse@gmail.com",
//     "contact": "7028589303"
//   },
//   "type": "link",
//   "view_less": 1,
//   "amount": 1000,
//   "currency": "INR",
//   "description": "Payment Link for this purpose - cvb.",
//   "receipt": "10000",
//   "reminder_enable": true,
//   "sms_notify": 1,
//   "email_notify": 1,
//   "expire_by": 1793630556,
//   "callback_url": "https://example-callback-url.com/",
//   "callback_method": "get"
// }'

$keyId='rzp_test_UuqopNwEkHsRf5';
$secretKey='jjpRUMAWVRjuOeNABjbKUPSN';
$api=new Api($keyId,$secretKey);

$Customer_Name=$_POST['NAME'];
$Customer_Email=$_POST['EMAIL'];
$Customer_ContactNo=$_POST['CONTACTNO'];
$PAY_AMT=$_POST['Price']*100;
$product_id=$_POST['product_id'];
$Customer_id=$_POST['customer_id'];

$order  = $api->order->create(array(
  'receipt'         => rand(1000,9999).'ORD',
  'amount'          => $PAY_AMT,
  'payment_capture' =>  1,
  'currency'        => 'INR',
)
);
?>
<meta name="viewport" charset="width=device-width">
<form action="success.php" method="POST"> 
<script
    src="https://checkout.razorpay.com/v1/checkout.js"
    data-key="<?php echo $keyId ?>" // Enter the Key ID generated from the Dashboard
    data-amount="<?php echo $order->amount; ?>" // Amount is in currency subunits. Default currency is INR. Hence, 50000 refers to 50000 paise
    data-currency="INR"
    data-order_id="<?php echo $order->id; ?>"//This is a sample Order ID. Pass the `id` obtained in the response of the previous step.
    data-buttontext="Pay Now"
    data-name="Cake Shop"
    data-description="For payment"
    data-image="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBUVFRgVFRYVFRUSERISGBgYGBIYGBgYGBkaGRgYGBgcIS4lHB4rHxgZJjgmKy8xNTU2GiQ7QDszPy40NTEBDAwMEA8QGhESGjQhISE0NDQ0NDE0NDQ1MTE0NDQ0MTQxMTQ0MTQxNDQ0NDQ0MTQ0NDE0MTExNDQ0NDE0NDU9NP/AABEIAKgBKwMBIgACEQEDEQH/xAAcAAABBQEBAQAAAAAAAAAAAAACAAEDBAYFBwj/xAA9EAACAQIDBgMFBgQFBQAAAAABAgADEQQSIQUTIjFBUQZhgTJScZGxBxRCkqHRI2LB8CQzQ3KiNVOCwvH/xAAZAQEBAQEBAQAAAAAAAAAAAAAAAQIDBAX/xAAiEQEBAAICAgICAwAAAAAAAAAAAQIRAyESMQRBUaETcZH/2gAMAwEAAhEDEQA/APLwwj3jZDHCGEOD5RxGCGPkMAgscJ5wLecUolFoWYSvHECfNCDyECEBCpM8IPAUQwIiCBhAxhDCyqIGErGCBCUQJg5ivGUQwhgOohgRKhhhJQ6SS8FQPOSADsYCBkixlEkCiA6iGsG4jh/hAMG0K/pIy5MJWkVKI1+0G94jAe8aDeENYU1vOEFPeEEjQBy/CEFHYR7xsxigWUdpzcUozHTt9BOnmnOxZ4z6fQSUZLM0cZo+aK8MFlMa0K8QEAbRwDCAj5TAYLCCQgsUBwsNUg3hK0oIU5IqwQ3nDB84BgRwIIhq0AlWSKsdCJIJQSJCZLRIJKRCbRC8JSYiI9oU6gwwpjLJFgMqwlQxwZKDABaZhikYatCDQuwLThhBDUiGLQbMKemkZqRk2kkvpBtT3UcJJC8YEQpoj8IVh3jESASI9oVossGw2nPxYGc+n0E6eWc7FjjPp9BAxW88o4eCEhCnMsiDCEHHaBaKUTCqI++kNohAsM1xeQ3jXitAMQ1gqphgSwEBJFgrNP4Y8I1cYrVcy0KCBr1XuQSvtBVuLgdTcAfOBycFhVdKzszKaNJKgAAObNVp07G5Fvbv6ToY7ZihA6aZcLg6jpxG7VgQSrE+8OXKx9JHtTZ9TBuMtRXp4iiHSqnsVEJDcm5EMqm3MEKe0qNtCoylC91ZKdMiyWKU9UXl06QLG0MDuWKF0d0qVKTqpBKtTIBP+0kkA6HgbQSoGh4nFO5zOxY8yTa50Aux/EbAam50mxXwnQVqGGqPV+94ug9RSu73VNspZVdSMzA5WBIP4fOBj1qSRakgSWEI7ShM5MQYyUBe8s4DBNXqLSpLmdzYDlyFySegABMCmAZo/DWx0anWxWIBahhhYICVNRyBZCw1A4l/MPOc/amyHw54yjDO1PMjq6h1tmpsR7LC40Nuc1+BwbNshaaAZsTieZ0UKtS7Mx6KFpEk9hJVZba9NClGtTQUhWSpmQMzKrI5W6ltbEZdO4M5wv3l3a2JRnVKZvSoIKSEixYAlncjpmdmb4EDpKQMoJb95IGMjuYQvAO5hZzIzHBgTCpFvTABMMr3gLMIs8QYQcokXQt5GzxskfLIpZor/GLLEFMBeplDFDiOvb6CdC05+K9o+n0EDLGoYBYxZDHyQwaOI+Xzj5YCEIRgohKBLoIKJMjeUAAQ7rAkzm3aRgx94I2YQLGEw7VHSmnt1aiU1/3OwUfqZ6X9peNGGw9DZ9A5VyBntzKIcqK3fMwZj3K+ZmR+z2hn2jhha4Wo7nyyU3cH8wWW/tGxWfaNYHUUxSpj4CmrH/k7R9jg1doVGopQZr0qLOyCy8Jc3bitexOtpepeG8YSn+HqgVmVELIyrduVyRwjrrOr9nWyRXxaMwBp0CKjXtYvru015ksC1uyGbTZdWo20N7WzCpiXq08PSJ/ysNSzZqzIeRbKFHXjY8jFI87p7HZMZTw1ZQG+8UabgEMCHZORHMFW/Wb/AMS1Bh8XWx1XQ0qC4bCKdDUqspLOB7i52BPmeoE5ewcL972vWrn/AC6GId79GZLpSUedkzfBDNDtWiKGJOIYgLnD1cTWAIp0x7GFwyNe7NbUqPxHroJR5HSp3sFBJNgANSb6AADnNJtPwjXw9Le1DS4VRmRXJqKrEKGZbWtmIBIJ1nQ8IImK2m1ZUsi1KuJC2Fl14AbaA5mU/ESPxPtemHxKI7VauIqlKjlSqpTpvwUUB1Oqi7aA5dOd5Rlcwmj8B4taeNpFuVTPSv2Liy/NrD1lTHkUMPToWAqV8uKqm2oUgihT/KWYj+YTkUcxZQl85ZQmX2sxPDl872lGl8WVVp1HwyBgFxVTEuzWuz1BdcoHJFQgDvcnSd3byVFwWCwlPMXrgEovN+HMynyzPc304deUl8XoqLQxT0adTEVFTDOS2elTqre5KDR2DZ11Nhl1Blj7Q9rLRCImld6bLmGhSizcWXsWKWuOimRWTxXhp0oPiBUpOtGoKdRULnKxKggMRZrF1vbTn2k3hrw22JVqjsKVCnfM5FySBchRcaAakn9enUxv+H2PTQ6Ni3V7fylt4D+VEHrLGOxVTD7LwpoZ0apUp3K3zEtnf1zMB8RpGxldr4DcuuQl6dVFek5ULnU9QATbXTWx8hO34m2DTw6oiAmqy0spDMz1GO83nB0UZUsQPxW16X9s45RicNhTSoVHQUEd2U8FSo4NTKikJ1DajrJPHGOf7yuHoL/Fq0qaF1vvGVncimp/CvMk9euggYZ0KtlZWVgQMpBDXPIWOt4b0ijFXBVlNirAgg9iDyM3Himo1HC4eqrI1chMO1dQGewRicjnXUqeLnzta8wJN/XUxBOHhgg85Xy+cQlErLAsI2aEKiyKYAd48QdY+cQbK8WaNvBFvBCkWnPxLcR9PoJf3gnPxL8R9PoJKm2QzmOHMW7MQpmGT5jHDGIIY+QwFmjhoshj5ICzRwYgsJVlDiSKYISSKIGk+z3FintHDM1grO9Mk/zo6L/zKy743wLttStTRWZ61SnkUDVi1NDp5aHXkLG/KZJHIIIuCCCCOYI5ETR47xfiq4ObdK7UxReslMJXemDfI1S+ikkkhQt4DbaxK0VTCUXuMPUNSpUQ+3ibWZkYa5UHAp/3HrOl9n+2Ep401cRUtnw9RA9RmbjJQrmc3NrKwuZkQloQEaHpXgbFK2MTD0WL0MNRr1nqFcpr1mCo9Ug+yvHlUcwL35zlYPadXHUdoI5escqYugli7U8tTUUlGoGRlBA/qZl9n4+rQZmouyM6NTYrbVWtddR5Dz0kNKoyEFCykcipKkdNCI0bbPYe1Rs2tSptzbjxdhdlLqRTp6f9sHMR3dh0kW1cDhFxL4hsRRrYd6jVlo03z1ajMc27YAWRcxN2J5dLnTJD6yVqbC1wRmGYXBFxqLi/MaHXyMaEmPxj1qj1X9uo5Y25DoFHkAAB5ATs7JH3fDPjP9V6hwuH/kbLepW+IU5V7EzgqvnO5gaiVKAw9Z3pKlc1UqKhqAZ1CsjICDrlBBF+sDu1/wDodPNzOKYrfn/mVCde/tTLUmfE1qaO7u9R6dEM7MzAMwUC56DMZ1/Eu2adSnRwuHDChhh7TABne1s2XpzY/FzytOHg8QaVRKigFqVRKgB5EowYA+WkDd+N6e/xtDCKQtOjRzueQRDrUY9sqIvzA6zgYjxZiN45pOFpGoHpoyU3CBAFplQwOUhVXl1vB214m3+8KUVotiSu+feF3cKqqtMEqMqcIJUczOCpiQaLwajVcfSZyWOepWcnmSEdrn/yt85e2rtRfv8AiiXFMsj4WnUIZhTYBEZrLci4VxcDQveH9mdK+Kdzyp4dz6syAfpeZPEVS7u551HeofixLH6wrQeK9tU3p0MLhyWo4VFGcgrndUyAgHUADN8S3lrmc3nCvGIlDZj3j3Jg2jhTAK8JY14OeFTAwswkAeHngSXglx2jGrG3kgfMO0gqYix0A9VU/USXe+UpV34j6fSSjPb4Rt9K+aLNKxpYFaPvJWDws8KsbyIPIA8LPAsBpd2Zhd7VRLOc7W4FzMNOduw5nyvOYrz1z7PfDC0TTxLvmqvSV1prayI9mAY/icix6Actec58mUxnvW2sZu+t6QbG+ztSCK7Wq2JCi9grDha2huNe4nC8V+D3wfGpapSDBGdlylWa+W4BIKm1r9+g0nsy0yKhqHUFVUC2qi9zrz1P0lbamzfvFCtRqarUHA17cuJL291h6icOO5S92939O2erOpOp+3z6LS/syvSR0NRCyh3LH2hYpZLp1CvZjrqNLQNqYJ8PVejVCh0IDZSGGoBBB7WIlPeCex5Xfw2Ow+WzinnBrcS0uFg2F3aWuLi1UB7kCxJIA1AJ9oUMrqgVDUwrUyRTGUOHosri4zAsiPcEtZjo1jw53OIQcQNLU2hhrvlRBmGMKZqakIr0lWgjCxzOrgnPr1Nze0g2viqDqd0EDb4kWQpwGlTBvoP9RXNumbTScLMIaQu2pw2Owm+zMibnMrKm7OYIXpko7EEMwRXF7G+Y8QzXDpi8Nkw+e7CkER7oSHValVyqMwBBXOhIvZg1jawvU8NbBfE1BZSKSEM7srZLA6oCCLk6iwPyns+BwNNKaoiDJTUhAbtYHnq2p9ewmLlJdNSPHGxNEo6sqZ8tkZEK8SqqjRwdDqT7JBF9b2kuzNoU0QBmcZQxKWbVy1w6MNCLKgKtYXp31J09hrbMo1CxelTc1FVXLIpzKpLKDprYm8x3jLwZT3T18OhV0zO6A6OpJZiFt7Q1sBYW+AiZGmDw2LGWuHID1UXKxRWswdXPThuARpp8JfxO0aDPVKpStvAaRNI5TTvULoVWxD8aWP8AJa45zPZxBzibRpFxmGUJkADbvEU2YpzL4ZUQlcvSoHJ1b2iQbGwq4jEUSqZU4lVlcKMgbgUI97XDZsxK3YG1wRmIHHVxJVqCB1tj7aqYfebvLetSNMkgmwP4l19ofKc/NI84jFxAMvLezcPvXycZNibIhc2HU6gKP5iQNZRUE3sCbAk2Hr/Sc8Y5KoKgZGN1JZ21GmhW1hrr+k58mep03x47vbXYnZ1GnUNN3JFVAKZVVchlYM7EDitlB6D2tdOfOx+FahUam4IKnQ62ZejKSNQe8t7GxozUxUalwruxZ1u6WKlRnAObK5Fw2lxzsBNBt/YrV0z5f4lOmxDKLmqFAsjLfRgAdRe9+XQcuLO777d+TjmumN3ixCqJXYWuCLEGxB0IPYxrz0vMtCuILVhK8e0CXext7IrRrQJd4JUruMx9PpJpTr+0fT6QM6GHaEGEPJHCyIjLjtFmHaSZIgkoDMIQIj7uOEgX9h7P+8V6dHOE3jFcxF7WUtYDqTaw8yJ7bsItRCUfbSmiopYLmOUAXuOthynn32Z06Yeo7ANUstNLlQVU6sy36k2Fxyt5z0msozAEWJGYMDxaeQ5/GeLntuU1fTrhOv7aKjVzDhN7cx1HkRJkcDmCJw8KhvmVrnvfn8dZ2qRYjX6zWFt9mU084+0fw1h6WHFahTo0yKxqVGLWd89+Fc3tcRvl6W0E8vz+U+lsXSVkYMFy2J4gCo8yDppznzRiEyuyhgwV2UMNA1iRmA6A8/WejC/TllCZ/K0YXggwlcjtNsjAMMKRra9tfj5SIEzT+BqKPiAXanZQwNN0Zy6kG5TSykG2t78+esmV1NrO7p6nsCgiYZFpgKgVXsAbjMATckkk3PPWd1DwgdQJxqNIqbLohVRYchbl6Wl5K1l1HYaEHnPLjlvuuti/TN+Uk5ixFwQRY9vMSnTPUHQ66f1kz1lXVmAF7XYgC/b9J1xSvMPtH2Iy1jiFRVpFaNPhsOMh/wAIUAaIOp5r3sMKwnqn2jbZpnCtTW1Q1HTiQgrTysGDMR1NrAefz8kYnvO2Pcc71Uto4kJc94lYjzl0bWQ/lBLmRiqewkj4q/4VGlusaNqe0MfUVQmhpM2YiynjtbW/MW+kophqbahgL66i9vgRrDxuMZXYH2WVQVvoQNbFb663gU6WHbkzIfj+883J1be5/T0YdzXVX8FgT7K1wAGVwGUmzdwb6cv0noPhjAVFqLWbEozKpQEhr2Optc2HxnndHYpb2K6HyYFTNPsbw3UI4mrA2vdDSK6dBc3vOO9/e/09GM69a/a74q8ONQ/jq4dKjnMequ1zrbmDrr6fHM+om6wfhWo9EpWZwWcsjXFlAvlLLyJsdR8rTC4rDvTd6bWzU6j0zbldSQbHtpPXx25Tt5OTGY3ovUR7+cgIaELzenPaXN5xZz3kfF5Qrt5fKNGzlz5SuxMmCtAYN2iw24UeNeK8yHiBjXivLsFePAzRZo2OngtoBAFNjfpb9ZocLWRsrBmVkuVKsysMpscpGsyOGyMbMAeo9Of6En0E6tKghFsrcqgFmNszLmXnyF1b+zPBz8WPluXVe3h5LrVm49H2N4mcWV93X0HExCP19plBB5dhNBQ8RoVByZSRf2xbnYajp6TymlRp/hzi4e12HMUg6m1upJHpOlTwyDo1tGALG1tyXA/P9J5/LPHry/128OPLvTZbT2kHY56lwBworErzHT8RvPOPFeEFOvcaGqgqlbWy5iRY/HLf1mowFRUPCqg5bX63svXtdG/NMd4ixTVMTUZjfK2QfBBl+oPznX4dmXLbvd05/K6wkk1NudHAg5os0+m+ckEtYDFmi61FzcBuQpsWXqv/AN8pRNSNvYs3NLGuwP2lFHOekd3/ABGUB7texCK4JAAva/XSBsv7QKxzb1Q7FFKkNuwLNrlUIc2pvz6WmPUhmZQgYlc2oBvplue1r3v5QnqUtbUwRavl5ixZVem3O2mot2nHxxnTrLXoFL7Q6xCECnwFt4LPY5XB014eC/PrLG0fGr1MocJw1CEyA2sbAEktYHXmbWzHmJ5/mouGYIVOSpbjcEZKClOuvH85cDUN667tcmcqrHM5IzUU6nWxLtqfLpL4yNTKfhqMVtDfpURDnyJUdwBlyBVzZm1NuTa9SAPjlbTvvttzhmphQgcIHIsur8bKLcxfOPhacImdOPWunPlt32a0GSZoJm3MgIssG8cVIHA2hTYOxOtz01sOQuOnSVUtfiuPh+0t7VFqhI/EFP8AfqJUCX6/3cfvOV9txYo3BsGynh0PLU/Kw53mg2dicYgGRzyva+gF7am+htrbtM8tG4N2XhDnz4bWA+JMtU8OQCgqkC7i1yFuMi8vMtz/AJZm4433G8csp6ehbMxVc2+81SUJCugsvBci4bNyNh20M5W0KabxyhLI1RmUnU2JvqepF7X8pyNm4NS2rPVUAk5mYLpdhYA63GT5n07CqLachN8ckt0nLlbJtXFIQhRk+WEonZyQClDFGTZYaiBAtKVK9PiPp9J1QspYocR9PoJKRjM0YvGyRZJxaNvIJqQt3G3cADVjGqZJuo25kUFKqQwPYzV4SxA7grcdNGGv/Npl9xLdB6ijhYgcuQP1nLl4rnOnXiz8fbW0FA4e2QfCwamT9J0KC5gNdSiWFgD/AJbAzF08ZWH4weZuQCdTfr5yxQ2hWW38RuE3Gi6c/LzM8efxM79x68fkYz6b3BU78RsApdiSbABS17ntrPO8TWzO7e87t8yT/WWHxTvcszNc31YkfLkJUqLPT8X4/wDDu27tcOfm/k1+IDeQWqRFIJSet5QNWld65lg0oLYeTtUFOrc3POxA0v8A31nUwyBrc7EAaWv7NRB/6Tm/dyDcS5gy6W5EBlNjpyIPPpy/WZyxt9NTKT2sUqFwbDnTqEelBD/Uzo0MIxZrA670aC+oasfQcC/KRYfFEZeDVAQOLmDTya8PYCdOltfISURQSzMLksRmLX5WB9tpi45X6dJljPsW10VERVGXM7tlvf2Qqg8upLTl5pNi8Q1Q5mNza3SwHYAcpVInbDHxx0455eWWzs8FngsJE6GaYJ8RKz4+3nCekTKz4WZu2ukGLxGcg9haAh09D/SGcMY6U2HQTNlWWJVBJIt7RI+br+0tUVJsbc82vnd3+fCsHD3BuUvxKfa7MWOlvP8ASdLAJbQrpw9bahUU9P5T85my/h0lx/Lq7Po5UbyIpjzsbg/ly/KWAYCNwgC2munewF7+kJWnXjx1O3PkymV6EBeGtoKCGf75TowI+sML8ZGohXMA1QSli/aPp9BLy+ko4v2jr2+gkpGOyxWhRCcmg2j5YQitLoMBHCx7RQEBDWNaGsiw4EkVYKiSqsy2QEB1koEFlliVBliCyS0ICbY2iKQlSGRCEARTENU8ohJBCaCBJAIgscQpWg2kl4JHWVKErBZJIBeIiEQGnBenLNoikaFPdCGlGWQklCS6ENOiJdpJaCiSZZRMPKSLAUQlMoPLeLL6R1J6QhrAe/QRxftAyww0CQGUMV7R9PoJdvKOKbiPp9BJSMjmEQI7iKKcmhAjvFmiigPFeKKAQaECO4iikWJUYdx8xJVYdx8xFFIp869x8xAdx3HzEeKWFDnHcfMRw47j5iKKaZLOO4iVx3EeKVBZx3HzEMVB3HzEUUijDr7w+YhCovvD5iKKAt6vvD5iLeL7w+YiilSkHX3l+YiLr7y/MRRRsNvF95fmI5qL7y/MRRShxUX3l/MJLvU95fmsUUAt+nvL+YSRaqe8v5liig0lXEJ76fmX94Yrp76fmX94opdmjb9B+NPzL+8kGKT30/Mv7xRRsOMUnvp+Zf3hDEp76fmX94oo2aF94T30/Ov7yhiay5jxp0/EvYRRSWkf/9k="
    data-prefill.name="<?php echo $Customer_Name; ?>"
    data-prefill.email="<?php echo $Customer_Email; ?>"
    data-prefill.contact="<?php echo $Customer_ContactNo; ?>"
    data-theme.color="#f77a14"
></script>
<input type="hidden" custom="Hidden Element" name="hidden">
<input type="text" name="product_id" value="<?php echo $product_id;?>" hidden>
<input type="text" name="customer_id" value="<?php echo $Customer_id;?>" hidden>
</form>
<script >
	document.getElementsByClassName('razorpay-payment-button')[0].click();
	document.getElementsByClassName('razorpay-payment-button')[0].style.display="none";

</script>
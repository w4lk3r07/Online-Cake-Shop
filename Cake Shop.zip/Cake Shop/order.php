<?php
session_start();
include 'connect.php';
$id=$_GET['id'];
if(isset($_POST['cart'])) {
  if(isset($_SESSION['user']))
  {
$username=$_SESSION['user'];
$sql1="SELECT * FROM users where USERNAME='$username'";
$result1=mysqli_query($conn,$sql1);
$row1 = mysqli_fetch_assoc($result1);
$uid=$row1['id'];

  $sqlcart="INSERT INTO `cart`(`user_id`, `product_id`) VALUES ('$uid','$id')";
  if(mysqli_query($conn,$sqlcart)){
    echo "<script>alert('Item added to the cart')</script>";
  }
  else{
    echo "<script>alert('Error')</script>";
  }
}
else{
echo "<script>alert('To access this feature, Please login')</script>";
}
}
$sql="SELECT * FROM product WHERE id='$id'";
$result=mysqli_query($conn,$sql);
while($row=mysqli_fetch_array($result))
		{
?>

<!DOCTYPE html>
<html>
<head>
	<title>Complete Your Order</title>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <style type="text/css">
    body{
     background-image: url(./images/background.jpg);
     }
     .bg-info{
      background-color: dimgray !important;
     }
  </style>
</head>

<body>
	<style type="text/css">
   body{
     background-image: url(./images/background.jpg);
     } 
		h3{
			font-size: 20px;
		}
		footer {
   position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: red;
   color: white;
   text-align: center;
}
	</style>
<nav class="navbar navbar-expand-md bg-dark navbar-dark">
  <!-- Brand -->
   <img src="./images/logo.png" style="width: 5%">
  <a class="navbar-brand" href="index.php">Cake Shop</a>

  <!-- Toggler/collapsibe Button -->
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>

  <!-- Navbar links -->
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item">
        <a class="nav-link" href="index.php">Home</a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         Category
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown" style="background-color: rgb(52,58,64);">
          <a class="dropdown-item " href="chocolate.php" style="color: rgb(153,156,159);">Chocolate</a>
          <a class="dropdown-item " href="redVelvet.php" style="color: rgb(153,156,159);">Red Velvet</a>
          <a class="dropdown-item " href="strawberry.php" style="color: rgb(153,156,159);">Strawberry</a>
          <a class="dropdown-item " href="blackForest.php" style="color: rgb(153,156,159);">Black Forest</a>

      </li>
      <?php
      if(!isset($_SESSION["user"]))  
 {       
 ?>
      <li class="nav-item">
        <a class="nav-link" href="login.php">LOGIN</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="insert.php">SIGN UP</a>
      </li>
<?php
}  
if(isset($_SESSION["user"]))  
 {       
 ?>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         Hi <?php echo $_SESSION["user"]?>
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown" style="background-color: rgb(52,58,64);">
          <a class="dropdown-item " href="myorder.php" style="color: rgb(153,156,159);">My Orders</a>
          <a class="dropdown-item " href="logout.php" style="color: rgb(153,156,159);">Logout</a>
      </li>
      <li><a href="cart.php"><i class="fa fa-shopping-cart" style="font-size:27px; color: rgb(153,156,159); margin-top: 6px; padding-left: 5px;"></i></a></li>

<?php
}  
?>
    </ul>
  </div>
</nav> 
<div class="container">
		<div class="card deck">
				<div class="card border-info p-2 text-center">
					<div class="row">
						<div class="col-lg-3">
					<h3>Image</h3>
				</div>
				<div class="col-lg-3">
					<h3> Product Description</h3>
				</div>
				<div class="col-lg-3">
					<h3>Price</h3>
				</div>
				<div class="col-lg-3">
					<h3>Checkout</h3>
				</div>
			</div>
				</div>
			</div>
<div class="card deck">
				<div class="card border-info p-2 bg-info text-center">
					<div class="row">
						<div class="col-lg-3">
					<img src="<?php echo $row['product_Image'];?>" class="card-img-top" height="160">
				</div>
				<div class="col-lg-3">
					<h5 class="card-title"><?php echo $row['product_name']; ?></h5>
				</div>
				<div class="col-lg-3">
					<h3><?php echo number_format($row['product_price']);?></h3>
				</div>
				<div class="col-lg-3">
					<a href="details.php?id=<?php echo $row['id'];?>" class="btn btn-danger btn-block btn-lg" style="margin-top: 10px;" >CHECKOUT NOW</a>
          <form method="POST">
            <input type="submit" name="cart" value="Add to Cart" class="btn btn-danger btn-block btn-lg" style="margin-top: 45px;">
          </form>
				</div>
			</div>
				</div>
			</div>
	</div>
	<?php
}
?>
<script type="text/javascript">
  function addcart() {
    // body...
  }
</script>
</body>
<footer class="ftco-footer ftco-section bg-dark text-center">
    <div class="container">
      <h5  class="mb-0" style="color: white;" >All Rights are reserved by Cake Shop</h5>
      </div>
    </footer>
</html>
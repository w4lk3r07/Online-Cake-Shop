<?php  
 session_start();  
 if(isset($_SESSION["admin"]))  
 {  
      header("location:add.php");  
 }  
 
 ?>
<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>Admin Login</title>
  <link rel="stylesheet" href="css/style.css">
  <style type="text/css">
    body{
     background-image: url(./assets/img/background.jpg);
     }
    footer {
     position: fixed;
     left: 0;
     bottom: 0;
     width: 100%;
     background-color: red;
     color: white;
     text-align: center;
}
h1{
  font-size: 130%;
  font-weight: bold;
  color: white;
  text-align: center;
}
  </style>

  
</head>

<body>


 <div class="container">


      <div id="login">

        <form method="post">

          <fieldset class="clearfix">
                        <h1>Admin Login:</h1>
            <p><span class="fontawesome-user"></span><input type="text"  name="user" value="Username" onBlur="if(this.value == '') this.value = 'Username'" onFocus="if(this.value == 'Username') this.value = ''" required></p> <!-- JS because of IE support; better: placeholder="Username" -->
            <p><span class="fontawesome-lock"></span><input type="password" name="pass"  value="Password" onBlur="if(this.value == '') this.value = 'Password'" onFocus="if(this.value == 'Password') this.value = ''" required></p> <!-- JS because of IE support; better: placeholder="Password" -->
            <a><input type="submit" name="sub"  value="Login"></a>

          </fieldset>

        </form>

       

      </div> <!-- end login -->

    </div>
    <div class="bottom" style="margin-top: 30%">  <h3><a href="../index.php">Back to Homepage</a></h3></div>
  
  
</body>
</html>

<?php
   //include('db.php');
  include '../connect.php';
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form 
      
      $myusername = mysqli_real_escape_string($conn,$_POST['user']);
      $mypassword = mysqli_real_escape_string($conn,$_POST['pass']); 
      
      $sql = "SELECT id FROM login WHERE usname = '$myusername' and pass = '$mypassword'";
      $result = mysqli_query($conn,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      $active = $row['active'];
      
      $count = mysqli_num_rows($result);
      
      // If result matched $myusername and $mypassword, table row must be 1 row
		
      if($count == 1) {
         
         $_SESSION['admin'] = $myusername;
         
         header("location: add.php");
      }else {
         echo '<script>alert("Your Username or Password is invalid") </script>' ;
      }
   }
?>
